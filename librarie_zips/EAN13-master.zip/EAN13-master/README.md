# C language EAN13/UPC-A barcode generator

Based on: https://github.com/astrokin/EAN13BarcodeGenerator

Implements a simple EAN13/UPC-A barcode generator for use in C applications
